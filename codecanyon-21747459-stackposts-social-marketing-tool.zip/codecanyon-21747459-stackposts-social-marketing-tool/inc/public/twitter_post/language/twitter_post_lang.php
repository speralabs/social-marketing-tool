<?php
$lang["Twitter Post"] = "Twitter Post";
$lang["Success"] = "Success";
$lang["Photo"] = "Photo";
$lang["Video"] = "Video";
$lang["Link"] = "Link";
$lang["Text"] = "Text";
$lang["Last 30 days"] = "Last 30 days";
$lang["Successed"] = "Successed";
$lang["Failed"] = "Failed";
$lang["Post type"] = "Post type";
$lang["Total"] = "Total";
$lang["Advance option"] = "Advance option";
$lang["Searching..."] = "Searching...";
$lang["Enter location"] = "Enter location";
$lang["Anonymous"] = "Anonymous";
$lang["@username"] = "@username";
$lang["Post"] = "Post";
