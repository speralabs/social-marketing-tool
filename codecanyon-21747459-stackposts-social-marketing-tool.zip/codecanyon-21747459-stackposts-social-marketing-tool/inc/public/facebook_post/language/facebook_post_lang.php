<?php
$lang["Facebook Post"] = "Facebook Post";
$lang["Post"] = "Post";
$lang["Media"] = "Media";
$lang["Link"] = "Link";
$lang["Text"] = "Text";
$lang["Last 30 days"] = "Last 30 days";
$lang["Successed"] = "Successed";
$lang["Failed"] = "Failed";
$lang["Post type"] = "Post type";
$lang["Total"] = "Total";
$lang["Anonymous"] = "Anonymous";
$lang["Like"] = "Like";
$lang["Comment"] = "Comment";
$lang["Share"] = "Share";