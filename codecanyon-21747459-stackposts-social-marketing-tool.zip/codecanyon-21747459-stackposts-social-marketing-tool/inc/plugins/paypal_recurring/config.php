<?php
return [
    'id' => 'paypal',
    'name' => 'Paypal recurring',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'far fa-list-alt',
    'color' => '#74788d',
];