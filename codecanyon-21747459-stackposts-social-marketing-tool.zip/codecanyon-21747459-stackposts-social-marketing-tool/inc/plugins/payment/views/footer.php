	<script type="text/javascript" src="<?php _e( get_module_path($this, "assets/plugins/izitoast/js/izitoast.js") )?>"></script>
	<script type="text/javascript" src="<?php _e( get_module_path($this, "assets/js/payment.js") )?>"></script>
	<script type="text/javascript" src="<?php _e( get_module_path($this, "assets/js/core.js") )?>"></script>
</body>
</html>