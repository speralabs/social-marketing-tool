How to install?

Open ftp:

upload all folders to /public_html/inc/public/ ->HERE<-


and import SQL File database.sql

Done!