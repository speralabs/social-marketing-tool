How to install?

Open ftp:

upload all folders to /public_html/inc/plugins/ ->HERE<-


Done!