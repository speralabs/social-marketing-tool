Open ftp:

instagram_activity folder upload to /public_html/inc/public/ ->HERE<-

open phpMyAdmin: 
Import SQL File database.sql

Done!