<div class="subheader-main wrap-m w-100 p-r-0"> 
	<div class="wrap-c">
		<button type="button" class="btn btn-label-info m-r-10 subheader-toggle"><i class="fas fa-bars"></i></button>
		<h3 class="title"><i class="<?php _e( $module_icon )?>" style="color: <?php _e( $module_color )?>"></i> <?php _e( $module_name )?></h3>
	</div>
</div>	