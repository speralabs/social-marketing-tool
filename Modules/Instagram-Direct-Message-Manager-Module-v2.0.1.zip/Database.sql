INSERT INTO `sp_purchase_manager` (`id`, `ids`, `item_id`, `purchase_code`, `version`) VALUES
(5, 'qi5b1gxww5w5al8oxcj3d0k498czbi1s', '22334544', 'Instagram Direct Message Manager Module For Stackposts', '2.0.1');

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------